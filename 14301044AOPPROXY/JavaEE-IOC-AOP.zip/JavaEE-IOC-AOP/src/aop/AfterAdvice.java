package aop;

public interface AfterAdvice extends Advice{

}
