package aop;

public interface Advisor {
	Advice getAdvice();
}
