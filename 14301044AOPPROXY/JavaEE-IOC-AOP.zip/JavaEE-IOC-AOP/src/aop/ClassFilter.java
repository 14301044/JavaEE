package aop;

public interface ClassFilter {
	boolean matches(Class<?> cls);
}
