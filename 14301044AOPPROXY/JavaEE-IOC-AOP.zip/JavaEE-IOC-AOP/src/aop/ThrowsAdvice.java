package aop;

public interface ThrowsAdvice extends AfterAdvice {
}
