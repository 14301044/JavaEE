package aop;

public interface AopProxy {
	Object getProxy();
}
