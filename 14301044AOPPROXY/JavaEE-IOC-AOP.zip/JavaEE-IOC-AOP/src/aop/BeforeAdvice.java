package aop;

public interface BeforeAdvice extends Advice {
}
