package aop.framework;

public interface FactoryBean {
	Object getObject();
}
