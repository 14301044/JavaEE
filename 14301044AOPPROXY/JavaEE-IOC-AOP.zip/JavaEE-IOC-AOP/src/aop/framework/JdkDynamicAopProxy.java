package aop.framework;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import aop.AfterReturningAdvice;
import aop.AopProxy;
import aop.MethodBeforeAdvice;
import aop.MethodInterceptor;
import aop.ThrowsAdvice;
import aop.support.AfterReturningAdviceInterceptor;
import aop.support.MethodBeforeAdviceInterceptor;
import aop.support.PointcutAdvisor;
import aop.support.ThrowsAdviceInterceptor;

public class JdkDynamicAopProxy implements AopProxy, InvocationHandler{

	private AdvisedSupport advised;
	
	public JdkDynamicAopProxy(AdvisedSupport advised)
	{
		this.advised = advised;
	}
	
	public Object getProxy()
	{
		return Proxy.newProxyInstance(
				this.getClass().getClassLoader(),
				new Class[]{advised.getInterfaces()}, 
				this);
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		
		PointcutAdvisor pointcutAdvisor = (PointcutAdvisor) advised.getAdvisor();
		
		if(pointcutAdvisor.getPointcut().getMethodMatcher().matches(method, advised.getTargetSource().getTarget().getClass()))
		{
			
			if(advised.getAdvisor().getAdvice() instanceof MethodBeforeAdvice)
			{
				MethodBeforeAdvice advice = (MethodBeforeAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new MethodBeforeAdviceInterceptor(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
			if(advised.getAdvisor().getAdvice() instanceof AfterReturningAdvice)
			{
				AfterReturningAdvice advice = (AfterReturningAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new AfterReturningAdviceInterceptor(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
			if(advised.getAdvisor().getAdvice() instanceof ThrowsAdvice)
			{
				ThrowsAdvice advice = (ThrowsAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new ThrowsAdviceInterceptor(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
		}
			
		return method.invoke(advised.getTargetSource().getTarget(), args);
	}

}
