package aop.framework;

import aop.Advice;
import aop.support.Advisor;
import aop.support.NameMatchMethodPointcutAdvisor;
import aop.support.TargetSource;
import bean.PropertyValues;
import factory.BeanFactory;
import factory.XMLBeanFactory;
import resource.LocalFileResource;
import test.ISubject;
import test.SimpleLogBeforeMehtod;

public class ProxyFactoryBean implements FactoryBean{
	//�����Ľӿ�
	private String proxyInterfaces;
	//������Ŀ����
	private Object target;
	//advisor
	private String interceptorName;
	
	
	public String getProxyInterfaces() {
		return proxyInterfaces;
	}


	public void setProxyInterfaces(String proxyInterfaces) {
		this.proxyInterfaces = proxyInterfaces;
	}


	public Object getTarget() {
		return target;
	}


	public void setTarget(Object target) {
		this.target = target;
	}


	public String getInterceptorName() {
		return interceptorName;
	}


	public void setInterceptorName(String interceptorName) {
		this.interceptorName = interceptorName;
	}


	@Override
	public Object getObject() {
		// TODO Auto-generated method stub
		LocalFileResource resource = new LocalFileResource("beans.xml");
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		
		TargetSource targetSource = new TargetSource();
		targetSource.setTarget(this.target);
		
		ProxyFactory proxyFactory = new ProxyFactory();
		proxyFactory.setTargetSource(targetSource);
		try {
			proxyFactory.setInterfaces(Class.forName(this.proxyInterfaces));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Advisor ad = (Advisor)beanFactory.getBean(this.interceptorName);
		NameMatchMethodPointcutAdvisor advisor = new NameMatchMethodPointcutAdvisor();
		advisor.setAdvice((Advice)ad.getAdvice());
		advisor.setMappedName(ad.getMappedName());
		proxyFactory.setAdvisor(advisor);
		
		
		return proxyFactory.getProxy();
	}

}
