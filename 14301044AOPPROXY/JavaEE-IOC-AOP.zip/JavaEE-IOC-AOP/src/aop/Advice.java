package aop;

public interface Advice {

}
