package test;

public interface ISubject {
	void printFirstMessage();
	void printSecondMessage();
}
