package test;

import java.lang.reflect.Method;

import aop.MethodBeforeAdvice;

public class SimpleLogBeforeMehtod implements MethodBeforeAdvice{

	@Override
	public void before(Method method, Object[] args, Object target) {
		System.out.println("The Advice Method");
	}

}
