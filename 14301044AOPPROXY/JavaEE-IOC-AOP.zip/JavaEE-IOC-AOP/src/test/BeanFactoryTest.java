package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import aop.framework.ProxyFactory;
import aop.framework.ProxyFactoryBean;
import aop.support.NameMatchMethodPointcutAdvisor;
import aop.support.TargetSource;
import factory.BeanFactory;
import factory.XMLBeanFactory;
import resource.LocalFileResource;

public class BeanFactoryTest {

	public static void main(String[] args) {
		LocalFileResource resource = new LocalFileResource("beans.xml");

		BeanFactory beanFactory = new XMLBeanFactory(resource);
		// the BeanDefinition doesn`t create the real bean yet
		ProxyFactoryBean proy = (ProxyFactoryBean)beanFactory.getBean("subjectProxy");
		ISubject sub = (ISubject)proy.getObject();
		
		sub.printFirstMessage();
		sub.printSecondMessage();
	}
}
