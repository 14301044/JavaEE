package mvc.controller;

import javax.servlet.http.HttpServletRequest;

public class CalculateController {
	
	public int add(Integer[] a) {
		int result=0;
		for (int i = 0; i < a.length; i++) {
			result+=a[i];
		}
		return result;
	}
	
}
