package mvc.controller;

import javax.servlet.http.HttpServletRequest;

public class CalculateController {

	public int add(Integer a, Integer b) {
		return a + b;
	}

}
