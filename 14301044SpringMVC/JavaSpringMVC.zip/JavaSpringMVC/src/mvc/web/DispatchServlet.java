package mvc.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Spring.factory.BeanFactory;
import Spring.factory.XMLBeanFactory;
import Spring.resource.LocalFileResource;
import mvc.controller.CalculateController;

/**
 * Servlet implementation class DispatchServlet
 */
@WebServlet("*.do")
public class DispatchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DispatchServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());
		String uri = request.getRequestURI();

		String controllername = uri.substring(uri.indexOf("/JavaSpringMVC/") + "/JavaSpringMVC/".length(),
				uri.indexOf("/", uri.indexOf("/JavaSpringMVC/") + "/JavaSpringMVC/".length()));
		String methodname = uri.substring(uri.lastIndexOf("/") + 1, uri.lastIndexOf("."));
		Enumeration<String> parameternames = request.getParameterNames();
		ArrayList<Object> parametervalues = new ArrayList<Object>();
		while (parameternames.hasMoreElements()) {
			parametervalues.add(request.getParameterValues(parameternames.nextElement())[0]);
		}

		LocalFileResource resource = new LocalFileResource(
				getServletContext().getRealPath("WEB-INF/classes/beans.xml"));
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		CalculateController controller = (CalculateController) beanFactory.getBean(controllername);

		try {
			Method m = controller.getClass().getMethod(methodname, Integer.class, Integer.class);
			Class<?> types[] = m.getParameterTypes();
			for (int i = 0; i < types.length; i++) {
				if (types[i] == Integer.class) {
					parametervalues.set(i, Integer.parseInt((String) parametervalues.get(i)));
				} else {
					parametervalues.set(i, (String) parametervalues.get(i));
				}
			}
			response.getWriter()
					.append(m.invoke(controller, parametervalues.get(0), parametervalues.get(1)).toString());
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = request.getRequestURI();

		String controllername = uri.substring(uri.indexOf("/JavaSpringMVC/") + "/JavaSpringMVC/".length(),
				uri.indexOf("/", uri.indexOf("/JavaSpringMVC/") + "/JavaSpringMVC/".length()));
		String methodname = uri.substring(uri.lastIndexOf("/") + 1, uri.lastIndexOf("."));
		System.out.println(methodname);
		
		ArrayList<Object> parametervalues = new ArrayList<Object>();
		
		LocalFileResource resource = new LocalFileResource(
				getServletContext().getRealPath("WEB-INF/classes/beans.xml"));
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		CalculateController controller = (CalculateController) beanFactory.getBean(controllername);
		
		try {
			Method m = controller.getClass().getMethod(methodname, Integer.class, Integer.class);
			Parameter p[]=m.getParameters();
			for (Parameter parameter : p) {
				System.out.println(parameter.getName());
				parametervalues.add(request.getParameter(parameter.getName()));
			}
			Class<?> types[] = m.getParameterTypes();
			for (int i = 0; i < types.length; i++) {
				if (types[i] == Integer.class) {
					parametervalues.set(i, Integer.parseInt((String) parametervalues.get(i)));
				} else {
					parametervalues.set(i, (String) parametervalues.get(i));
				}
			}
					request.setAttribute("result", (m.invoke(controller, parametervalues.get(0), parametervalues.get(1)).toString()));
					request.getRequestDispatcher("/add.jsp").forward(request, response);
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
