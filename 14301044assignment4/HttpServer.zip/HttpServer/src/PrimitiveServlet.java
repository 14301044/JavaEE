
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class PrimitiveServlet implements Servlet {

	public void destroy() {
		System.out.println("destroy");

	}

	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	public void init(ServletConfig arg0) throws ServletException {
		System.out.println("init");

	}

	public void service(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=gb2312"); 
		System.out.println("form service");
		PrintWriter out = response.getWriter();
		out.println("<head>");
		out.println("<title>this is a jsp</title>");
		out.println("</head>");
		out.println("<a href=\"http://www.baidu.com\">Hello,roses are red</a><BR>");
		out.println("<h>violets are blues</h>");

	}

}
