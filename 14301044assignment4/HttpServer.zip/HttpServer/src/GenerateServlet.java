import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class GenerateServlet {
	private String servletname = "";
	private String jspname = "";
	private File readfile = null;
	private File writefile = null;
	private FileOutputStream out = null;
	private FileInputStream in = null;

	public GenerateServlet(String jspname) {
		// TODO Auto-generated constructor stub
		this.servletname = jspname.substring(jspname.indexOf("/") + 1, jspname.indexOf("."));
		this.jspname = jspname.substring(jspname.indexOf("/") + 1);
		if (judgeExist()) {
			readAndwriteServlet();
		}
	}

	public boolean judgeExist() {
		readfile = new File("src/" + jspname);
		if (readfile.exists()) {
			return true;
		} else {
			return false;
		}
	}

	private void readAndwriteServlet() {
		String contentType = "";
		String[] importClass = null;
		String tempString = "";
		List<String> codeList = new ArrayList<String>();
		int first = 1;
		try {
			writefile = new File("bin/" + "Myservlet" + servletname + ".java");
			out = new FileOutputStream(writefile);
			BufferedReader bfReader = new BufferedReader(new FileReader(readfile));
			while ((tempString = bfReader.readLine()) != null) {
				if (tempString.contains("<") || tempString.contains(">")) {
					if (tempString.contains("<%@")) {
						// System.out.println(tempString +
						// tempString.indexOf("contentType=\""));
						contentType = tempString.substring(
								tempString.indexOf("contentType=\"") + "contentType=\"".length(), tempString.indexOf(
										"\"", tempString.indexOf("contentType=\"") + "contentType=\"".length() + 1));
						contentType = "response.setContentType(" +"\"" + contentType + "\"" + ");";
						importClass = tempString
								.substring(tempString.indexOf("import=\"") + "import=\"".length(), tempString
										.indexOf(";", tempString.indexOf("import=\"") + "import=\"".length() + 1))
								.split(",");
						continue;
					} else if (tempString.contains("<%")) {
						if (tempString.contains("<%=")) {
							tempString = tempString.replace("<%=", "out.print(");
							tempString = tempString.replace("%>", ");out.println(\"\");");
						}
						tempString = tempString.replace("<%", "out.println(\"\");");
						tempString = tempString.replace("%>", "out.println(\"\");");
					} else if (tempString.contains("%>")) {
						tempString = tempString.replace("%>", "out.println(\"\");");
					} else {
						tempString = "out.println(\"" + tempString + "\");";
					}
				} else if(!tempString.contains(";")){
					tempString = "out.println(\"" + tempString + "\");";
				}
				tempString = tempString.replace(";", ";\r\n");
				codeList.add(tempString);
			}
			bfReader.close();
			//дͷ�ļ�
			out.write(("import javax.servlet.*;\r\n").getBytes());
			out.write(("import java.io.*;\r\n").getBytes());
			for (int i = 0; i < importClass.length; i++) {
				out.write(("import " + importClass[i] + ";\r\n").getBytes());
				System.out.println(importClass[i]);
			}
			//д����
			out.write(("public class "+"Myservlet" +servletname+" implements Servlet {\r\n").getBytes());
			//д���ط���
			out.write(("public void destroy() {\r\nSystem.out.println(\"destroy\");\r\n}\r\n"
					+ "public ServletConfig getServletConfig() {\r\n"
					+ "return null;\r\n"
					+ "}\r\n"
					+ "public String getServletInfo() {\r\n"
					+ "return null;\r\n"
					+ "}\r\n"
					+ "public void init(ServletConfig arg0) throws ServletException {\r\n"
					+ "System.out.println(\"init\");\r\n"
							+ "}\r\n").getBytes());
			//дservice����
			out.write(("public void service(ServletRequest request, ServletResponse response)"
					+ "throws ServletException, IOException {\r\n").getBytes());
			out.write((contentType + "\r\n").getBytes());
			out.write(("PrintWriter out = response.getWriter();\r\n").getBytes());
			System.out.println(contentType);
			for (String string : codeList) {
				out.write((string).getBytes());
				System.out.println(string);
			}
			out.write(("}\r\n}\r\n").getBytes());
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new GenerateServlet("1.jsp");
	}
}
