
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
 
import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler.CompilationTask;
 
public class Complier {
 
    /**
     * @param args
     * @throws Exception 
     * ��-824.40 -824.40 
     */
 
    public void textJavaCompiler(String filepathname) throws IOException{
        // �������
        JavaCompiler javaCompiler = ToolProvider.getSystemJavaCompiler();
        int result = javaCompiler.run(null, null, null, filepathname);
        System.out.println( result == 0 ? "��ϲ����ɹ�" : "�Բ������ʧ��");
    }
 
}