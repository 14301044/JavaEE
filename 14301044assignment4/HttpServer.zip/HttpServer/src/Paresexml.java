import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Paresexml {
	private File xmlFile = null;
	private NodeList nList = null;

	public Paresexml() {
		// TODO Auto-generated constructor stub
		xmlFile = new File("src/web.xml");
	}

	public void parse() {
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();

		DocumentBuilder builder;
		try {
			builder = builderFactory.newDocumentBuilder();
			Document doc = builder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			nList = doc.getElementsByTagName("servlet-mapping");
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean judgeuri(Request request) {
		for (int i = 0; i < nList.getLength(); i++) {
			Node node = nList.item(i);
			Element ele = (Element) node;
			if (node.getNodeType() == Element.ELEMENT_NODE) {
				System.out.println("uri name: " + ele.getElementsByTagName("url-pattern").item(0).getTextContent());
				if (ele.getElementsByTagName("url-pattern").item(0).getTextContent().equals(request.getUri())) {
					return true;
				}
			}
		}
		return false;
	}
}
